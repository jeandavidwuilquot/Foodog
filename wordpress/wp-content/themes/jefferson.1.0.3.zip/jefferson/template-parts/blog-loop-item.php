<article id="post-<?php the_ID(); ?>" <?php post_class( 'ccfw-blog-loop-item' ); ?>>
	<div class="container">
		<div class="row">
			<?php echo jefferson_blog_loop_item(); ?>
		</div>
	</div>
</article><!-- #post-## -->